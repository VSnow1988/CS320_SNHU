package app;

public class Contact {
	
	// Instance variables
	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	
	// Constructor taking arguments for all fields
	public Contact (String ID, String fName, String lName, String phone, String address) {
		
		//Check that phone string is all digits
		char[] phoneArray;
		Boolean phoneDigits = true;
		if (phone != null) {
			phoneArray = phone.toCharArray();
			for(char c : phoneArray) {
				if(!Character.isDigit(c)) {
					phoneDigits = false;
				}
			}
		}
		
		//Throw exceptions for invalid entries
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid Contact ID.");
		}
		
		else if (fName == null || fName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name.");
		}
		
		else if (lName == null || lName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name.");
		}
		
		else if (phone == null || phone.length() != 10 || phoneDigits == false ) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		else if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address.");
		}

		
		this.contactID = ID;
		this.firstName = fName;
		this.lastName = lName;
		this.phone = phone;
		this.address = address;
	}
	
	// Setter methods for updating fields
	public Contact setFirstName(String fName) {
		this.firstName = fName;
		return this;
	}
	
	public Contact setLastName(String lName) {
		this.lastName = lName;
		return this;
	}
	
	public Contact setPhone(String phone) {
		this.phone = phone;
		return this;
	}
	
	public Contact setAddress(String address) {
		this.address = address;
		return this;
	}
	
	//Getter methods for retrieving private data
	public String getID() {
		return this.contactID;
	}
	
	public String getFName() {
		return this.firstName;
	}
	
	public String getLName() {
		return this.lastName;
	}
	
	public String getPhone() {
		return this.phone;
	}
	
	public String getAddress() {
		return this.address;
	}

}
