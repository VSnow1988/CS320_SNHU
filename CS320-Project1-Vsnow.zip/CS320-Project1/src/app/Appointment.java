package app;

import java.util.Date;

public class Appointment {

		// Instance variables
		private String apptID;
		private Date apptDate;
		private String apptDescription;		
		
		// Constructor taking arguments for all fields
		public Appointment (String ID, Date date, String description) {
			
			//Throw exceptions for invalid entries
			if (ID == null || ID.length() > 10) {
				throw new IllegalArgumentException("Invalid Appointment ID.");
			}
			
			else if (date == null || date.before(new Date())) {
				throw new IllegalArgumentException("Invalid Date.");
			}
			
			else if (description == null || description.length() > 50) {
				throw new IllegalArgumentException("Invalid last name.");
			}
			
			this.apptID = ID;
			this.apptDate = date;
			this.apptDescription = description;
		}
		
		// Setter methods for updating fields
		public Appointment setFirstName(Date date) {
			this.apptDate = date;
			return this;
		}
		
		public Appointment description(String description) {
			this.apptDescription = description;
			return this;
		}
		
		
		//Getter methods for retrieving private data
		public String getID() {
			return this.apptID;
		}
		
		public Date getDate() {
			return this.apptDate;
		}
		
		public String getDescription() {
			return this.apptDescription;
		}	
}
