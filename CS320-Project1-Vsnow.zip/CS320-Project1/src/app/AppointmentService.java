package app;

import java.util.ArrayList;

public class AppointmentService {

	// ArrayList to hold Appointments
	private ArrayList<Appointment> appointmentsList = new ArrayList<Appointment>();
		
	//Public Accessor method
	public ArrayList<Appointment> getList(){
		return this.appointmentsList;
	}	
	
	// Service Methods
	public void addAppointment(Appointment newAppointment) {
		
		//Throw error if ID is not unique.
		for (int i = 0; i < this.appointmentsList.size(); i++) {
			if (newAppointment.getID().equals(this.appointmentsList.get(i).getID())) {
				throw new IllegalArgumentException("ID is not unique.");
			}
		}
		
		//Add to list.
		this.appointmentsList.add(newAppointment);
		
	}
	
	public void deleteAppointment(String ID) {
		for (int i = 0; i < this.appointmentsList.size(); i++){ // Check the list
			if (this.appointmentsList.get(i).getID().equals(ID)) { // If ID matches current item
				this.appointmentsList.remove(i); // Remove it
				return; // End function
			}
		}
		throw new IllegalArgumentException("Contact ID not found.");
	}
}
