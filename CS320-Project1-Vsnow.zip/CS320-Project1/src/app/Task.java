package app;

public class Task {

	// Private fields to hold data
	private String taskID;
	private String name;
	private String description;
	
	// Constructor with all fields filled
	public Task (String taskID, String name, String description) {
		
		// Throw exception for invalid entries
		if (taskID == null || taskID.length() > 10 ) {
			throw new IllegalArgumentException("Invalid ID.");
		}
		else if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name.");
		}
		else if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description.");
		}
		
		// Construct the object
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	
	// Setter methods for updating fields
	public Task setName(String name){
		this.name = name;
		return this;
	}
	
	public Task setDescription(String description){
		this.description = description;
		return this;
	}
	
	// Getter methods for retrieving information
	public String getID() {
		return this.taskID;
	}
	public String getName() {
		return this.name;
	}
	
	public String getDescription() {
		return this.description;
	}
}

