package app;
import java.util.ArrayList;
import app.ContactService;

public class ContactService {
	
	// ArrayList to hold Contacts
	private ArrayList<Contact> contactsList = new ArrayList<Contact>();
	
	//Public Accessor method
	public ArrayList<Contact> getList(){
		return this.contactsList;
	}
	
	// Service Methods
	public void addContact(Contact newContact) {
		
		//Throw error if ID is not unique.
		for (int i = 0; i < this.contactsList.size(); i++) {
			if (newContact.getID().equals(this.contactsList.get(i).getID())) {
				throw new IllegalArgumentException("ID is not unique.");
			}
		}
		
		//Add to list.
		this.contactsList.add(newContact);
		
	}
	
	public void deleteContact(String ID) {
		for (int i = 0; i < this.contactsList.size(); i++){ // Check the list
			if (this.contactsList.get(i).getID().equals(ID)) { // If ID matches current item
				this.contactsList.remove(i); // Remove it
				return; // End function
			}
		}
		throw new IllegalArgumentException("Contact ID not found.");
	}
	
	public void updateContact(Contact newContact) {
		for (int i = 0; i < this.contactsList.size(); i++){ // Check the list
			if (this.contactsList.get(i).getID().equals(newContact.getID())) { // If ID matches current item
				this.contactsList.set(i, newContact); // Update it
				return; // End function
			}
		}
		throw new IllegalArgumentException("Contact ID not found.");
	}
		

	public static void main(String[] args) {
		
		//Test main, prints to console.
		System.out.println("Hello.");
		
	}
	
}
