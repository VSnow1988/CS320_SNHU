package app;
import java.util.ArrayList;
import app.Task;

public class TaskService {
	
	// ArrayList to hold Contacts
	private ArrayList<Task> tasksList = new ArrayList<Task>();
	
	//Public Accessor method
	public ArrayList<Task> getList(){
		return this.tasksList;
	}
	
	// Service Methods
	public void addTask(Task newTask) {
		
		//Throw error if ID is not unique.
		for (int i = 0; i < this.tasksList.size(); i++) {
			if (newTask.getID().equals(this.tasksList.get(i).getID())) {
				throw new IllegalArgumentException("ID is not unique.");
			}
		}
		
		//Add to list.
		this.tasksList.add(newTask);
		
	}
	
	public void deleteTask(String ID) {
		for (int i = 0; i < this.tasksList.size(); i++){ // Check the list
			if (this.tasksList.get(i).getID().equals(ID)) { // If ID matches current item
				this.tasksList.remove(i); // Remove it
				return; // End function
			}
		}
		throw new IllegalArgumentException("Task ID not found.");
	}
	
	public void updateTask(Task newTask) {
		for (int i = 0; i < this.tasksList.size(); i++){ // Check the list
			if (this.tasksList.get(i).getID().equals(newTask.getID())) { // If ID matches current item
				this.tasksList.set(i, newTask); // Update it
				return; // End function
			}
		}
		throw new IllegalArgumentException("Task ID not found.");
	}
		

	public static void main(String[] args) {
		
		//Test main, prints to console.
		System.out.println("Hello.");
		
	}
	
}
