module cs320p1 {
	requires junit;
}