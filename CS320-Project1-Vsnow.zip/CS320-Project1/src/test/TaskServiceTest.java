package test;

import static org.junit.Assert.*;

import app.TaskService;
import app.Task;
import org.junit.Test;

public class TaskServiceTest {
	
	private Task testTask = new Task("0","Step 1","Rustle their Jimmies.");
	private Task testTask2 = new Task("0","Step 2","??????????");
	private Task testTask3 = new Task("5","Step 3","Profit.");
	private TaskService testService = new TaskService();

	// Test that the added Task is in the list with the correct ID and information.
	@Test
	public void testTaskAdded() {
		testService.addTask(testTask);
		assertTrue(testService.getList().get(0).getID().equals("0"));
		assertTrue(testService.getList().get(0).getName().equals("Step 1"));
		assertTrue(testService.getList().get(0).getDescription().equals("Rustle their Jimmies."));
	}
	
	// Test that a repeated ID entry is rejected.
	@Test
	public void testAddTask() {
		testService.addTask(testTask);
		assertThrows(IllegalArgumentException.class, () -> {
			testService.addTask(testTask);
		});
	}
	
	// Test that a task has been deleted.
	@Test
	public void testTaskDeleted() {
		testService.addTask(testTask);
		testService.deleteTask("0");
		// Iterate the array
		for (int i = 0; i < testService.getList().size(); i++){
		assertFalse(testService.getList().get(i).getID().equals("0"));
		}
	}
	
	// Test that deletion throws an error when there is no ID match.
	@Test
	public void testDeleteTask() {
		testService.addTask(testTask);
		assertThrows(IllegalArgumentException.class, () -> {
			testService.deleteTask("abc");
		});
	}
	
	// Test that a contact has been updated by this method.
	@Test
	public void testTaskUpdated() {
		testService.addTask(testTask);
		testService.updateTask(testTask2);
		assertTrue(testService.getList().get(0).getID().equals("0"));
		assertTrue(testService.getList().get(0).getName().equals("Step 2"));
		assertTrue(testService.getList().get(0).getDescription().equals("??????????"));
	}
	
	// Test that update throws an error when there is no ID match. 
	@Test
	public void testUpdateTask() {
		testService.addTask(testTask);
		assertThrows(IllegalArgumentException.class, () -> {
			testService.updateTask(testTask3);
		});
	}

}
