package test;

import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
import app.Appointment;

public class AppointmentTest {
	
	//Note: Do not use the deprecated format for comparisons.
	Date future = new Date(909355008999900L);
	Date past = new Date(1000);

	@Test
	public void testAppointment() {
		Appointment Appointment = new Appointment("0123456789", future , "Abcdef gh");
		assertTrue(Appointment.getID().equals("0123456789"));
		assertTrue(Appointment.getDate().equals(future));
		assertTrue(Appointment.getDescription().equals("Abcdef gh"));
	}
	
	@Test
	public void testAppointmentIDtooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("abcdef tyu#", future, "123");
		});
	}
	
	@Test
	public void testAppointmentIDNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment(null, future, "Abc");
		});
	}
	
	@Test
	public void testAppointmentDateNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("12345", null, "Abc");
		});
	}
	
	@Test
	public void testAppointmentDatePast() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("12345", past , "Abc");
		});
	}
	
	@Test
	public void testAppointmentDescriptionNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment(null, future, "123");
		});
	}
	
	@Test
	public void testAppointmentDescriptionLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("qwerty uiop asdf ghjkl zxcv bnm  ,.? 1234567890 @#$!", future, "Abc");
		});
	}

}
