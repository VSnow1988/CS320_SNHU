package test;

import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
import app.Appointment;
import app.AppointmentService;

public class AppointmentServiceTest {
	
	Date future = new Date(2026, 12, 12);
	private AppointmentService testService = new AppointmentService();
	private Appointment testAppointment = new Appointment("0", future, "test valid entry");

	// Test that the added Appointment is in the list with the correct ID and information.
		@Test
		public void testAppointmentAdded() {
			testService.addAppointment(testAppointment);
			assertTrue(testService.getList().get(0).getID().equals("0"));
			assertTrue(testService.getList().get(0).getDate().equals(future));
			assertTrue(testService.getList().get(0).getDescription().equals("test valid entry"));
		}
		
		// Test that a repeated ID entry is rejected.
		@Test
		public void testAddAppointment() {
			testService.addAppointment(testAppointment);
			assertThrows(IllegalArgumentException.class, () -> {
				testService.addAppointment(testAppointment);
			});
		}
		
		// Test that a Appointment has been deleted.
		@Test
		public void testAppointmentDeleted() {
			testService.addAppointment(testAppointment);
			testService.deleteAppointment("0");
			// Iterate the array
			for (int i = 0; i < testService.getList().size(); i++){
			assertFalse(testService.getList().get(i).getID().equals("0"));
			}
		}
		
		// Test that deletion throws an error when there is no ID match.
		@Test
		public void testDeleteAppointment() {
			testService.addAppointment(testAppointment);
			assertThrows(IllegalArgumentException.class, () -> {
				testService.deleteAppointment("2");
			});
		}

}
