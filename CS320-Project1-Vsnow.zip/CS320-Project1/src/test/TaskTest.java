package test;

import static org.junit.Assert.*;
import org.junit.Test;
import app.Task;

public class TaskTest {

	@Test
	public void testTask() {
		Task task = new Task("123", "ABC", "abc");
		assertTrue(task.getID().equals("123"));
		assertTrue(task.getName().equals("ABC"));
		assertTrue(task.getDescription().equals("abc"));
	}
	
	@Test
	public void testTaskIDtooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Task("abc34f tyu#", "ABC", "abc");
		});
	}
	
	@Test
	public void testTaskIDNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Task(null, "ABC", "abc");
		});
	}

	@Test
	public void testTaskNametooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Task("123", "QWERTY @#$%^& ASDFghj", "abc");
		});
	}
	
	@Test
	public void testTaskNameNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Task("123", null, "abc");
		});
	}
	
	@Test
	public void testTaskDescriptiontooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Task("123", "ABC", "QWERTY @#$%^& ASDFghj2345167  + zxcvbnm/?;=<[ 8*uio");
		});
	}
	
	@Test
	public void testTaskDescriptionNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Task("123", "ABC", null);
		});
	}
}
