package test;

import static org.junit.Assert.assertThrows;
import org.junit.Test;
import app.Contact;
import junit.framework.TestCase;

public class ContactTest extends TestCase {
	
	@Test
	public void testContact() {
		Contact contact = new Contact("abc", "123", "Abc", "1234567890", "1230");
		assertTrue(contact.getID().equals("abc"));
		assertTrue(contact.getFName().equals("123"));
		assertTrue(contact.getLName().equals("Abc"));
		assertTrue(contact.getPhone().equals("1234567890"));
		assertTrue(contact.getAddress().equals("1230"));
	}
	
	@Test
	public void testContactIDtooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("abcdef tyu#", "123", "Abc", "1234567890", "1230");
		});
	}
	
	@Test
	public void testContactIDNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, "123", "Abc", "1234567890", "1230");
		});
	}
	
	@Test
	public void testContactFNameNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", null, "Abc", "1234567890", "1230");
		});
	}
	
	@Test
	public void testContactFNametooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "asdfg hjklo", "Abc", "1234567890", "1230");
		});
	}
	
	@Test
	public void testContactLNameNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", null, "1234567890", "1230");
		});
	}
	
	@Test
	public void testContactLNametooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", "Asdfghj %94", "1234567890", "1230");
		});
	}
	
	@Test
	public void testContactPhoneNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", "sprinkles", null, "1230");
		});
	}
	
	@Test
	public void testContactPhonetooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", "sprinkles", "129 000 $#sd", "1230");
		});
	}
	
	@Test
	public void testContactPhonenotDigits() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", "sprinkles", "qwert uiop", "1230");
		});
	}
	
	@Test
	public void testContactAddressNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", "sprinkles", "1234567890", null);
		});
	}
	
	@Test
	public void testContactAddresstooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345", "peter", "sprinkles", "1234567890", "1234567890 Very Long $treet Tulsa, OK");
		});
	}

}
