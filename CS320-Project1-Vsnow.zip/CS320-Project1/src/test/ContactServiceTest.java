package test;

import static org.junit.Assert.*;
import org.junit.Test;
import app.ContactService;
import app.Contact;

public class ContactServiceTest {

	private Contact testContact = new Contact("0","Jimmy","Rustler","1234567890","123 fake street");
	private Contact testContact2 = new Contact("0","Jimmy","Rustler","1234567890","123 real street");
	private Contact testContact3 = new Contact("5","Jimmy","Rustler","1234567890","123 new street");
	private ContactService testService = new ContactService();
	
	
	// Test that the added Contact is in the list with the correct ID and information.
	@Test
	public void testContactAdded() {
		testService.addContact(testContact);
		assertTrue(testService.getList().get(0).getID().equals("0"));
		assertTrue(testService.getList().get(0).getFName().equals("Jimmy"));
		assertTrue(testService.getList().get(0).getLName().equals("Rustler"));
		assertTrue(testService.getList().get(0).getPhone().equals("1234567890"));
		assertTrue(testService.getList().get(0).getAddress().equals("123 fake street"));
	}
	
	// Test that a repeated ID entry is rejected.
	@Test
	public void testAddContact() {
		testService.addContact(testContact);
		assertThrows(IllegalArgumentException.class, () -> {
			testService.addContact(testContact);
		});
	}
	
	// Test that a contact has been deleted.
	@Test
	public void testContactDeleted() {
		testService.addContact(testContact);
		testService.deleteContact("0");
		// Iterate the array
		for (int i = 0; i < testService.getList().size(); i++){
		assertFalse(testService.getList().get(i).getID().equals("0"));
		}
	}
	
	// Test that deletion throws an error when there is no ID match.
	@Test
	public void testDeleteContact() {
		testService.addContact(testContact);
		assertThrows(IllegalArgumentException.class, () -> {
			testService.deleteContact("abc");
		});
	}
	
	// Test that a contact has been updated by this method.
	@Test
	public void testContactUpdated() {
		testService.addContact(testContact);
		testService.updateContact(testContact2);
		assertTrue(testService.getList().get(0).getID().equals("0"));
		assertTrue(testService.getList().get(0).getFName().equals("Jimmy"));
		assertTrue(testService.getList().get(0).getLName().equals("Rustler"));
		assertTrue(testService.getList().get(0).getPhone().equals("1234567890"));
		assertTrue(testService.getList().get(0).getAddress().equals("123 real street"));
	}
	
	// Test that update throws an error when there is no ID match. 
	@Test
	public void testUpdateContact() {
		testService.addContact(testContact);
		assertThrows(IllegalArgumentException.class, () -> {
			testService.updateContact(testContact3);
		});
	}

}
